#include "LED.h"

void LED_Init(void) {
	// TODO
}

void Red_LED_Off(void) {
	// TODO
}

void Red_LED_On(void) {
	// TODO
}

void Red_LED_Toggle(void){
	// TODO
}

void Green_LED_Off(void) {
	// TODO
}

void Green_LED_On(void) {
	// TODO
}

void Green_LED_Toggle(void) {
	// TODO
}
